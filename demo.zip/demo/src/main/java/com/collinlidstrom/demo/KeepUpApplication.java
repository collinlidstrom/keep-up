package com.collinlidstrom.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeepUpApplication {

	public static void main(String[] args) {
		SpringApplication.run(KeepUpApplication.class, args);
	}

}
